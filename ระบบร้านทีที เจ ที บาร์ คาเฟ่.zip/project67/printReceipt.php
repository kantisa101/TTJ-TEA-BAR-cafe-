<?php
require_once('script/script.php');
$db_handle = new myDBControl();


?>