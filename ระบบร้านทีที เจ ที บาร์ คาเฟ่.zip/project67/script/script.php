<?php

class myDBControl
{
    private $host = "localhost";
    private $user = "std660101";
    private $password = "pro660101";
    private $database = "std660101db";
    private $conn;

    /* ฟังก์ชันหลัก สำหรับกำหนดค่าเริ่มต้นก่อนใช้งาน */
    function __construct()
    {
        $this->conn = $this->connectDB();
    }

    /* ฟังก์ชัน สำหรับติดต่อฐานข้อมูล */
    function connectDB()
    {
        $conn = mysqli_connect($this->host, $this->user, $this->password, $this->database);
        
        // ตรวจสอบการเชื่อมต่อ
        if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
        }
        
        // กำหนด charset ให้เป็น UTF-8
        mysqli_set_charset($conn, "utf8");

        return $conn;
    }

    /* ฟังก์ชัน สำหรับสืบค้นข้อมูล รับประโยคคำสั่งผ่าน $query */
    function Textquery($query)
    {
        $result = mysqli_query($this->conn, $query);

        if (!$result) {
            die("Query failed: " . mysqli_error($this->conn));
        }

        $resultset = [];
        while ($row = mysqli_fetch_assoc($result)) {
            $resultset[] = $row;
        }

        return !empty($resultset) ? $resultset : null;
    }

    /* ฟังก์ชัน สำหรับประมวลผลคำสั่ง INSERT, UPDATE, DELETE */
    function Execquery($query)
    {
        $result = mysqli_query($this->conn, $query);

        if (!$result) {
            die("Query failed: " . mysqli_error($this->conn));
        }

        return true;
    }

    /* ปิดการเชื่อมต่อฐานข้อมูล */
    function closeDB()
    {
        if ($this->conn) {
            mysqli_close($this->conn);
        }
    }

    /* ปิดการเชื่อมต่อเมื่อออบเจ็กต์ถูกทำลาย */
    function __destruct()
    {
        $this->closeDB();
    }
}
?>
